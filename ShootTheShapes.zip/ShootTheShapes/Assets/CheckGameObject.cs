using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CheckGameObject : MonoBehaviour
{
    public GameObject[] objectsToActivate;

    public bool nextobject=false;
    public int currentIndex = 0;

    private void Start()
    {
        DeactivateAllObjects();
        ActivateNextObject();
    }

    private void DeactivateAllObjects()
    {
        foreach (GameObject obj in objectsToActivate)
        {
            obj.SetActive(false);
        }
    }

    public void ActivateNextObject()
    {
        DeactivateAllObjects();

        if (objectsToActivate.Length > 0)
        {
            objectsToActivate[currentIndex].SetActive(true);
            currentIndex = (currentIndex + 1) % objectsToActivate.Length;
        }
    }

    public void GetObject()
    {
        IEnumerator  coroutine = NextObj(5.0f);
        StartCoroutine(coroutine);
    }
    private IEnumerator NextObj(float waitTime)
    {
            yield return new WaitForSeconds(waitTime);
            ActivateNextObject();
    }
}
