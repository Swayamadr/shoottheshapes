using UnityEngine;

public class CircleGenerator : MonoBehaviour
{
    public int numSegments = 36; // Number of segments in the circle
    public float radius = 1.0f; // Radius of the circle
    public float height = 0.1f; // Height of the circle

    void Start()
    {
        GenerateCircle();
    }

    void GenerateCircle()
    {
        MeshFilter meshFilter = GetComponent<MeshFilter>();
        MeshRenderer meshRenderer = GetComponent<MeshRenderer>();

        Mesh mesh = new Mesh();

        Vector3[] vertices = new Vector3[numSegments * 2];
        int[] triangles = new int[numSegments * 6];

        for (int i = 0; i < numSegments; i++)
        {
            float angle = 2f * Mathf.PI * i / numSegments;
            float x = Mathf.Cos(angle) * radius;
            float z = Mathf.Sin(angle) * radius;

            vertices[i] = new Vector3(x, 0f, z);
            vertices[i + numSegments] = new Vector3(x, height, z);

            int nextIndex = (i + 1) % numSegments;

            triangles[i * 6] = i;
            triangles[i * 6 + 1] = i + numSegments;
            triangles[i * 6 + 2] = nextIndex;

            triangles[i * 6 + 3] = i + numSegments;
            triangles[i * 6 + 4] = nextIndex + numSegments;
            triangles[i * 6 + 5] = nextIndex;
        }

        mesh.vertices = vertices;
        mesh.triangles = triangles;

        mesh.RecalculateNormals();

        meshFilter.mesh = mesh;
        meshRenderer.material = Resources.Load<Material>("CircleMaterial"); // Assign your material here
    }
}
