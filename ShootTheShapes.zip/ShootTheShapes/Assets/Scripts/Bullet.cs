using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    public float life = 3;
    private Renderer rend;
    private Material objectMaterial;
    private ColorDataArray colorDataArray;
    public TextAsset colorJsonFile;
    void Awake()
    {
        rend = GetComponent<Renderer>();
        objectMaterial = new Material(rend.material); // Create a copy of the object's material

        if (colorJsonFile != null)
        {
            colorDataArray = JsonUtility.FromJson<ColorDataArray>(colorJsonFile.text);
        }
        ChangeColor();
        Destroy(gameObject, life);
    }

    public void ChangeColor()
    {
      
        if (colorDataArray != null && colorDataArray.colors.Length > 0)
        {
            int randomIndex = Random.Range(0, colorDataArray.colors.Length);
            Color newColor = new Color(
                colorDataArray.colors[randomIndex].r,
                colorDataArray.colors[randomIndex].g,
                colorDataArray.colors[randomIndex].b,
                colorDataArray.colors[randomIndex].a);

            objectMaterial.SetColor("_Color", newColor);
            rend.material = objectMaterial; // Apply the new material with the random color
        }
        else
        {
            Debug.LogWarning("No color data available.");
        }
    }
   

}

[System.Serializable]
public class ColorData
{
    public float r;
    public float g;
    public float b;
    public float a;
}
[System.Serializable]
public class ColorDataArray
{
    public ColorData[] colors;
}