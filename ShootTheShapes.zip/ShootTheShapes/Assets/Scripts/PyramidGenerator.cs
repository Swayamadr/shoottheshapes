using UnityEngine;

public class PyramidGenerator : MonoBehaviour
{
    public float height = 3.0f; // Height of the pyramid
    public float baseSize = 3.0f; // Size of the pyramid's base

    void Start()
    {
        CreatePyramid();
    }

    void CreatePyramid()
    {
        // Add MeshFilter component
        MeshFilter meshFilter = gameObject.AddComponent<MeshFilter>();
        // Add MeshRenderer component
        MeshRenderer meshRenderer = gameObject.AddComponent<MeshRenderer>();
       // MeshCollider meshCollider = gameObject.AddComponent<MeshCollider>();
      
        // Add Rigidbody component
        Rigidbody rigidbody = gameObject.AddComponent<Rigidbody>();
        rigidbody.useGravity = false;
        rigidbody.isKinematic = true;

        Mesh mesh = new Mesh();

        Vector3 topVertex = new Vector3(0f, height, 0f);
        Vector3[] baseVertices = new Vector3[4];

        baseVertices[0] = new Vector3(-baseSize / 2, 0f, -baseSize / 2);
        baseVertices[1] = new Vector3(baseSize / 2, 0f, -baseSize / 2);
        baseVertices[2] = new Vector3(baseSize / 2, 0f, baseSize / 2);
        baseVertices[3] = new Vector3(-baseSize / 2, 0f, baseSize / 2);

        Vector3[] vertices = new Vector3[5];
        vertices[0] = topVertex;
        baseVertices.CopyTo(vertices, 1);

        int[] triangles = new int[]
        {
            0, 1, 2, // Front face
            0, 2, 3, // Right face
            0, 3, 4, // Back face
            0, 4, 1, // Left face
            1, 2, 3, // Base triangle 1
            1, 3, 4  // Base triangle 2
        };

        mesh.vertices = vertices;
        mesh.triangles = triangles;

        mesh.RecalculateNormals();

        meshFilter.mesh = mesh;
        meshRenderer.material = Resources.Load<Material>("PyramidMaterial"); // Assign your material here
        gameObject.AddComponent<MeshCollider>();
    }
}
